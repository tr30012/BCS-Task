from django.contrib import admin

from application.models import Transaction

admin.site.register(Transaction)
