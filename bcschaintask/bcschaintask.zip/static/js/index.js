buttoncallback = function () {
    alert("Pressed!")
}